import com.android.build.gradle.internal.api.BaseVariantOutputImpl

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.carmusic.diagnostic"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.carmusic.diagnostic"
        minSdk = 23
        // Android 11 = API 30
        targetSdk = 30
        versionCode = 2
        versionName = "1.1"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            // Firma con la clave debug para poder instalar el APK release sin keystore propio.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // Todos los APK salen como CarMusic-Diagnostic.apk
    applicationVariants.all {
        outputs.all {
            (this as BaseVariantOutputImpl).outputFileName = "CarMusic-Diagnostic.apk"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // targetSdk 30 es intencional (Android 11); no queremos que lint bloquee el build.
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Sin dependencias externas: solo APIs del framework Android + stdlib de Kotlin.
dependencies {
}
