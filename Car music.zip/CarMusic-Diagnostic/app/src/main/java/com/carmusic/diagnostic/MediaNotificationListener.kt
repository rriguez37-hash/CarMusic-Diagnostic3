package com.carmusic.diagnostic

import android.service.notification.NotificationListenerService
import android.util.Log

/**
 * Servicio mínimo. No lee ni procesa notificaciones.
 *
 * Android solo permite a una app normal consultar MediaSessionManager.getActiveSessions()
 * si tiene un NotificationListenerService habilitado por el usuario; este es ese servicio.
 */
class MediaNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(Diag.TAG, "NotificationListener conectado: acceso a sesiones multimedia disponible")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(Diag.TAG, "NotificationListener desconectado")
    }
}
