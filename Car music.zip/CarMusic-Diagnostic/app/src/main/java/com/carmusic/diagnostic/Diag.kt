package com.carmusic.diagnostic

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.util.Log

/** Tipo de carátula encontrada en una clave concreta de la metadata. */
enum class ArtKind {
    /** Imagen Bitmap incrustada en la metadata. */
    BITMAP,

    /** URI local (content://, file://, android.resource://...). */
    URI_LOCAL,

    /** URI remota http/https. La app no la descarga (no usa Internet). */
    URI_HTTPS,

    /** La clave no existe o está vacía. */
    ABSENT
}

/** Resultado de inspeccionar una clave de carátula. */
data class ArtReport(
    val key: String,
    val kind: ArtKind,
    val note: String,
    /** Solo no nulo si se obtuvo una imagen real (bitmap o URI local legible). */
    val bitmap: Bitmap?
)

/** Instantánea de una sesión multimedia activa. */
data class SessionSnapshot(
    val packageName: String,
    val appLabel: String,
    val bluetoothRelated: Boolean,
    val bluetoothReason: String,
    val hasMetadata: Boolean,
    val title: String?,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val positionMs: Long,
    val stateName: String,
    val isPlaying: Boolean,
    val artReports: List<ArtReport>,
    val metadataKeys: List<String>
) {
    /** Primera imagen realmente legible (bitmap o URI local). */
    val bestArt: Bitmap? get() = artReports.firstOrNull { it.bitmap != null }?.bitmap
    val hasArt: Boolean get() = bestArt != null

    /** Tipos de carátula presentes (vacío = completamente ausente). */
    val artKinds: Set<ArtKind>
        get() = artReports.map { it.kind }.filter { it != ArtKind.ABSENT }.toSet()
}

object Diag {
    const val TAG = "CarMusicDiag"
    const val YTM_PACKAGE = "com.google.android.apps.youtube.music"

    // Evita repetir en Logcat el mismo aviso en cada refresco.
    private val loggedOnce = HashSet<String>()

    private fun logOnce(key: String, msg: String, e: Throwable? = null) {
        if (!loggedOnce.add(key)) return
        if (e != null) Log.e(TAG, msg, e) else Log.w(TAG, msg)
    }

    /** ¿El usuario ha concedido "Acceso a notificaciones" a esta app? */
    fun isListenerEnabled(ctx: Context): Boolean = try {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
        val me = ComponentName(ctx, MediaNotificationListener::class.java)
        flat?.split(":")?.any { ComponentName.unflattenFromString(it) == me } == true
    } catch (e: Exception) {
        logOnce("listener-check", "Error comprobando acceso a notificaciones", e)
        false
    }

    /** Salidas de audio Bluetooth activas (A2DP / SCO). No requiere permisos. */
    fun bluetoothOutputs(ctx: Context): List<String> = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
            }
            .map {
                val kind = if (it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) "A2DP" else "SCO"
                "${it.productName} [$kind]"
            }
    } catch (e: Exception) {
        logOnce("bt-outputs", "Error consultando dispositivos de audio Bluetooth", e)
        emptyList()
    }

    fun snapshot(ctx: Context, c: MediaController, btAudioActive: Boolean): SessionSnapshot {
        val pkg = c.packageName ?: "?"
        val label = try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            // Con visibilidad de paquetes limitada (Android 11+) puede fallar; no es grave.
            logOnce("label-$pkg", "No se pudo resolver el nombre de $pkg: ${e.message}")
            pkg
        }

        val md: MediaMetadata? = try { c.metadata } catch (e: Exception) {
            logOnce("md-$pkg", "Error leyendo metadata de $pkg", e); null
        }
        val st: PlaybackState? = try { c.playbackState } catch (e: Exception) {
            logOnce("st-$pkg", "Error leyendo playbackState de $pkg", e); null
        }

        // Heurística de relación con Bluetooth
        val (btRelated, btReason) = when {
            pkg.contains("bluetooth", ignoreCase = true) ->
                true to "Sesión del propio stack Bluetooth del sistema"
            btAudioActive && st?.state == PlaybackState.STATE_PLAYING ->
                true to "Reproduciendo mientras hay salida de audio A2DP/SCO activa"
            btAudioActive ->
                false to "Hay salida Bluetooth activa, pero esta sesión no está reproduciendo"
            else ->
                false to "No hay salida de audio Bluetooth activa"
        }

        val duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var pos = st?.position ?: PlaybackState.PLAYBACK_POSITION_UNKNOWN
        if (st != null && st.state == PlaybackState.STATE_PLAYING && pos >= 0) {
            val elapsed = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
            pos += (elapsed * st.playbackSpeed).toLong()
            if (duration > 0 && pos > duration) pos = duration
        }

        return SessionSnapshot(
            packageName = pkg,
            appLabel = label,
            bluetoothRelated = btRelated,
            bluetoothReason = btReason,
            hasMetadata = md != null,
            title = md?.let { it.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: it.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) },
            artist = md?.let { it.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: it.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: it.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) },
            album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM),
            durationMs = duration,
            positionMs = pos,
            stateName = stateName(st?.state),
            isPlaying = st?.state == PlaybackState.STATE_PLAYING,
            artReports = if (md != null) inspectArt(ctx, md) else emptyList(),
            metadataKeys = md?.keySet()?.sorted() ?: emptyList()
        )
    }

    private fun inspectArt(ctx: Context, md: MediaMetadata): List<ArtReport> {
        val out = mutableListOf<ArtReport>()

        val bitmapKeys = listOf(
            "METADATA_KEY_ALBUM_ART" to MediaMetadata.METADATA_KEY_ALBUM_ART,
            "METADATA_KEY_ART" to MediaMetadata.METADATA_KEY_ART,
            "METADATA_KEY_DISPLAY_ICON (extra)" to MediaMetadata.METADATA_KEY_DISPLAY_ICON
        )
        for ((label, key) in bitmapKeys) {
            val bmp = try { md.getBitmap(key) } catch (e: Exception) {
                logOnce("bmp-$label", "Error leyendo $label", e); null
            }
            out += if (bmp != null) {
                ArtReport(label, ArtKind.BITMAP, "Bitmap ${bmp.width}x${bmp.height}", bmp)
            } else {
                ArtReport(label, ArtKind.ABSENT, "sin bitmap", null)
            }
        }

        val uriKeys = listOf(
            "METADATA_KEY_ALBUM_ART_URI" to MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            "METADATA_KEY_ART_URI" to MediaMetadata.METADATA_KEY_ART_URI,
            "METADATA_KEY_DISPLAY_ICON_URI (extra)" to MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        )
        for ((label, key) in uriKeys) {
            val uriStr = try { md.getString(key) } catch (e: Exception) {
                logOnce("uri-$label", "Error leyendo $label", e); null
            }
            out += if (uriStr.isNullOrBlank()) {
                ArtReport(label, ArtKind.ABSENT, "sin URI", null)
            } else {
                classifyUri(ctx, label, uriStr)
            }
        }
        return out
    }

    private fun classifyUri(ctx: Context, label: String, uriStr: String): ArtReport {
        val uri = Uri.parse(uriStr)
        val scheme = uri.scheme?.lowercase()
        if (scheme == "http" || scheme == "https") {
            // La app no usa Internet: solo informamos de que la URI existe.
            return ArtReport(
                label, ArtKind.URI_HTTPS,
                "URI ${scheme.uppercase()} presente (no descargada, la app no usa Internet): $uriStr",
                null
            )
        }
        return try {
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (bmp != null) {
                ArtReport(label, ArtKind.URI_LOCAL, "URI local legible ${bmp.width}x${bmp.height}: $uriStr", bmp)
            } else {
                ArtReport(label, ArtKind.URI_LOCAL, "URI local presente pero no decodificable: $uriStr", null)
            }
        } catch (e: SecurityException) {
            logOnce("sec-$uriStr", "Sin permiso para leer $uriStr", e)
            ArtReport(label, ArtKind.URI_LOCAL, "URI local presente pero sin permiso de lectura: $uriStr", null)
        } catch (e: Exception) {
            logOnce("io-$uriStr", "No se pudo abrir $uriStr", e)
            ArtReport(
                label, ArtKind.URI_LOCAL,
                "URI local presente pero falló la lectura (${e.javaClass.simpleName}): $uriStr", null
            )
        }
    }

    /** Texto detallado de una sesión (para pantalla y para copiar). */
    fun describe(s: SessionSnapshot, index: Int): String = buildString {
        appendLine("▸ Sesión $index: ${s.appLabel}")
        appendLine("  Paquete: ${s.packageName}")
        appendLine("  Estado: ${s.stateName}")
        appendLine(
            "  Bluetooth: ${if (s.bluetoothRelated) "relacionada" else "no relacionada"} — ${s.bluetoothReason}"
        )
        if (!s.hasMetadata) appendLine("  Sin MediaMetadata publicada")
        s.artReports.forEach {
            val mark = when (it.kind) {
                ArtKind.BITMAP -> "[BITMAP]   "
                ArtKind.URI_LOCAL -> "[URI LOCAL]"
                ArtKind.URI_HTTPS -> "[URI HTTPS]"
                ArtKind.ABSENT -> "[AUSENTE]  "
            }
            appendLine("  $mark ${it.key}: ${it.note}")
        }
        if (s.metadataKeys.isNotEmpty()) {
            appendLine("  Claves de metadata: ${s.metadataKeys.joinToString(", ")}")
        }
    }

    /** Firma estable (sin posición de reproducción) para detectar cambios reales. */
    fun signature(s: SessionSnapshot): String =
        listOf(
            s.packageName, s.stateName, s.title, s.artist, s.album, s.durationMs,
            s.artReports.joinToString(",") { "${it.kind}:${it.note}" },
            s.metadataKeys.joinToString(",")
        ).joinToString("|")

    private fun stateName(state: Int?): String = when (state) {
        null -> "sin estado"
        PlaybackState.STATE_PLAYING -> "reproduciendo"
        PlaybackState.STATE_PAUSED -> "pausado"
        PlaybackState.STATE_STOPPED -> "detenido"
        PlaybackState.STATE_BUFFERING -> "cargando"
        PlaybackState.STATE_CONNECTING -> "conectando"
        PlaybackState.STATE_NONE -> "ninguno"
        PlaybackState.STATE_ERROR -> "error"
        PlaybackState.STATE_FAST_FORWARDING -> "avance rápido"
        PlaybackState.STATE_REWINDING -> "retroceso"
        PlaybackState.STATE_SKIPPING_TO_NEXT -> "siguiente"
        PlaybackState.STATE_SKIPPING_TO_PREVIOUS -> "anterior"
        PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM -> "saltando en cola"
        else -> "desconocido ($state)"
    }

    fun formatTime(ms: Long): String {
        if (ms < 0) return "--:--"
        val total = ms / 1000
        return "%d:%02d".format(total / 60, total % 60)
    }
}
