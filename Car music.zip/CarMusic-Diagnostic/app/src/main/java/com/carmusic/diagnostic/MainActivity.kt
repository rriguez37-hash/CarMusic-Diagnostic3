package com.carmusic.diagnostic

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var msm: MediaSessionManager
    private lateinit var listenerComponent: ComponentName

    private lateinit var tvBluetooth: TextView
    private lateinit var tvSession: TextView
    private lateinit var tvPackage: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvAlbum: TextView
    private lateinit var tvDuration: TextView
    private lateinit var tvPosition: TextView
    private lateinit var tvState: TextView
    private lateinit var tvArt: TextView
    private lateinit var tvDetails: TextView
    private lateinit var ivArt: ImageView

    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = Runnable { refresh(force = false) }

    private val callbacks = mutableMapOf<MediaController, MediaController.Callback>()
    private var watchedTokens: List<MediaSession.Token> = emptyList()
    private var sessionsListenerRegistered = false

    /** Firma de lo último dibujado; si no cambia, no se redibuja ni se vuelve a registrar en Logcat. */
    private var lastSignature: String? = null

    /** Diagnóstico completo en texto, tal cual se copia al portapapeles. */
    private var lastReport: String = ""

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { scheduleRefresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerComponent = ComponentName(this, MediaNotificationListener::class.java)

        tvBluetooth = findViewById(R.id.tvBluetooth)
        tvSession = findViewById(R.id.tvSession)
        tvPackage = findViewById(R.id.tvPackage)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvAlbum = findViewById(R.id.tvAlbum)
        tvDuration = findViewById(R.id.tvDuration)
        tvPosition = findViewById(R.id.tvPosition)
        tvState = findViewById(R.id.tvState)
        tvArt = findViewById(R.id.tvArt)
        tvDetails = findViewById(R.id.tvDetails)
        ivArt = findViewById(R.id.ivArt)

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refresh(force = true) }
        findViewById<Button>(R.id.btnCopy).setOnClickListener { copyReport() }
        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                Log.e(Diag.TAG, "No se pudo abrir los ajustes de acceso a notificaciones", e)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        registerSessionsListener()
        refresh(force = true)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(refreshRunnable)
        clearCallbacks()
        if (sessionsListenerRegistered) {
            try {
                msm.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
                Log.e(Diag.TAG, "Error quitando listener de sesiones", e)
            }
            sessionsListenerRegistered = false
        }
    }

    // ---------------------------------------------------------------- refresco

    /** Agrupa ráfagas de eventos (metadata + estado + sesiones) en un solo refresco. */
    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, REFRESH_DEBOUNCE_MS)
    }

    private fun registerSessionsListener() {
        if (sessionsListenerRegistered || !Diag.isListenerEnabled(this)) return
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
            sessionsListenerRegistered = true
        } catch (e: SecurityException) {
            Log.e(Diag.TAG, "Sin acceso para escuchar sesiones multimedia", e)
        } catch (e: Exception) {
            Log.e(Diag.TAG, "Error registrando listener de sesiones", e)
        }
    }

    private fun clearCallbacks() {
        callbacks.forEach { (controller, cb) ->
            try { controller.unregisterCallback(cb) } catch (_: Exception) { }
        }
        callbacks.clear()
        watchedTokens = emptyList()
    }

    /** Solo vuelve a registrar callbacks si cambió el conjunto de sesiones. */
    private fun watch(controllers: List<MediaController>) {
        val tokens = controllers.map { it.sessionToken }
        if (tokens == watchedTokens) return
        clearCallbacks()
        for (c in controllers) {
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) = scheduleRefresh()
                override fun onPlaybackStateChanged(state: PlaybackState?) = scheduleRefresh()
                override fun onSessionDestroyed() = scheduleRefresh()
            }
            try {
                c.registerCallback(cb)
                callbacks[c] = cb
            } catch (e: Exception) {
                Log.e(Diag.TAG, "No se pudo observar ${c.packageName}", e)
            }
        }
        watchedTokens = tokens
    }

    private fun refresh(force: Boolean) {
        val enabled = Diag.isListenerEnabled(this)
        val bt = Diag.bluetoothOutputs(this)

        if (!enabled) {
            clearCallbacks()
            val sig = "noaccess|$bt"
            if (!force && sig == lastSignature) return
            lastSignature = sig
            renderBluetooth(bt)
            tvSession.text = getString(R.string.fmt_session, getString(R.string.not_detected))
            fillMain(null)
            setDetails(getString(R.string.no_access_help))
            Log.w(Diag.TAG, "Acceso a notificaciones NO concedido")
            return
        }
        registerSessionsListener()

        val controllers: List<MediaController> = try {
            msm.getActiveSessions(listenerComponent)
        } catch (e: Exception) {
            val msg = "${e.javaClass.simpleName}: ${e.message}"
            val sig = "error|$msg"
            if (!force && sig == lastSignature) return
            lastSignature = sig
            Log.e(Diag.TAG, "Error en getActiveSessions", e)
            renderBluetooth(bt)
            tvSession.text = getString(R.string.fmt_session, getString(R.string.not_detected))
            fillMain(null)
            setDetails(getString(R.string.error_prefix) + " " + msg)
            return
        }

        watch(controllers)
        val snaps = controllers.map { Diag.snapshot(this, it, bt.isNotEmpty()) }

        val sig = "ok|$bt|" + snaps.joinToString("##") { Diag.signature(it) }
        if (!force && sig == lastSignature) return
        lastSignature = sig

        render(snaps, bt)
    }

    // ---------------------------------------------------------------- dibujo

    private fun renderBluetooth(bt: List<String>) {
        tvBluetooth.text = getString(
            R.string.fmt_bluetooth,
            if (bt.isEmpty()) getString(R.string.disconnected)
            else getString(R.string.connected) + " — " + bt.joinToString(", ")
        )
    }

    private fun render(snaps: List<SessionSnapshot>, bt: List<String>) {
        renderBluetooth(bt)

        if (snaps.isEmpty()) {
            tvSession.text = getString(R.string.fmt_session, getString(R.string.not_detected))
            fillMain(null)
            setDetails(getString(R.string.no_sessions_help))
            Log.i(Diag.TAG, "Sin sesiones multimedia activas")
            return
        }

        // Prioridad: 1) YouTube Music, 2) sesión que reproduce, 3) primera del sistema.
        val ytm = snaps.firstOrNull { it.packageName == Diag.YTM_PACKAGE }
        val playing = snaps.firstOrNull { it.isPlaying }
        val (primary, reason) = when {
            ytm != null -> ytm to "1) Sesión de YouTube Music (${Diag.YTM_PACKAGE})"
            playing != null ->
                playing to "2) YouTube Music no tiene sesión activa; se usa la que está reproduciendo"
            else ->
                snaps.first() to "3) YouTube Music no tiene sesión y ninguna reproduce; se usa la primera del sistema"
        }

        tvSession.text = getString(
            R.string.fmt_session,
            getString(R.string.detected) + " (${snaps.size})"
        )
        fillMain(primary)

        val sb = StringBuilder()
        sb.appendLine("Selección: $reason")
        sb.appendLine()
        snaps.forEachIndexed { i, s ->
            sb.appendLine(Diag.describe(s, i + 1))
        }
        sb.append(conclusion(primary, snaps.any { it.packageName == Diag.YTM_PACKAGE }))
        setDetails(sb.toString())

        Log.i(
            Diag.TAG,
            "Sesiones=${snaps.size} principal=${primary.packageName} título=${primary.title} " +
                "estado=${primary.stateName} carátula=${primary.artKinds}"
        )
    }

    private fun conclusion(p: SessionSnapshot, ytmPresent: Boolean): String {
        val k = p.artKinds
        val sb = StringBuilder("── CONCLUSIÓN ──\n")
        if (!ytmPresent) {
            sb.appendLine("YouTube Music no tiene sesión activa en este momento; el análisis corresponde a ${p.appLabel}.")
        }
        when {
            p.hasArt -> sb.appendLine(
                "${p.appLabel} entrega una carátula como imagen legible (Bitmap o URI local). " +
                    "El teléfono la tiene; si la pantalla no la muestra, el límite está en el enlace Bluetooth o en la pantalla."
            )
            ArtKind.URI_LOCAL in k -> sb.appendLine(
                "${p.appLabel} publica una URI local pero esta app no pudo leerla (permiso o formato). " +
                    "Revisa el detalle de arriba y Logcat (CarMusicDiag)."
            )
            ArtKind.URI_HTTPS in k -> sb.appendLine(
                "${p.appLabel} SÍ publica carátula, como URI HTTPS. No se puede concluir que no la proporcione: " +
                    "esta app no usa Internet y por eso no la descarga. Falta una prueba de descarga (requeriría " +
                    "el permiso INTERNET, que no está añadido) para verificar la imagen."
            )
            else -> sb.appendLine(
                "En este momento ${p.appLabel} no publica ninguna clave de carátula (ni Bitmap ni URI). " +
                    "Cambia de canción y pulsa Actualizar para confirmar que no es un estado transitorio."
            )
        }
        if (p.hasArt && ArtKind.URI_HTTPS in k) {
            sb.appendLine("Además hay una URI HTTPS publicada.")
        }
        sb.append(
            "Nota: que la pantalla reciba el título por Bluetooth (AVRCP) no implica que una app externa lea todos " +
                "los metadatos, ni que tener la carátula en el teléfono (Bitmap, URI local o HTTPS) signifique que llegue al coche: " +
                "eso depende de AVRCP 1.6 con Cover Art en el teléfono y en la pantalla."
        )
        return sb.toString()
    }

    private fun fillMain(s: SessionSnapshot?) {
        val none = getString(R.string.none)
        tvPackage.text = getString(
            R.string.fmt_package,
            if (s == null) none
            else if (s.appLabel != s.packageName) "${s.packageName} (${s.appLabel})"
            else s.packageName
        )
        tvTitle.text = getString(R.string.fmt_title, s?.title ?: none)
        tvArtist.text = getString(R.string.fmt_artist, s?.artist ?: none)
        tvAlbum.text = getString(R.string.fmt_album, s?.album ?: none)
        tvDuration.text = getString(
            R.string.fmt_duration,
            if (s != null && s.durationMs > 0) Diag.formatTime(s.durationMs) else none
        )
        tvPosition.text = getString(
            R.string.fmt_position,
            if (s != null && s.positionMs >= 0) Diag.formatTime(s.positionMs) else none
        )
        tvState.text = getString(R.string.fmt_state, s?.stateName ?: none)

        if (s == null) {
            tvArt.text = getString(R.string.fmt_art, none)
            tvArt.setTextColor(Color.WHITE)
        } else {
            val k = s.artKinds
            val parts = mutableListOf<String>()
            if (ArtKind.BITMAP in k) parts += getString(R.string.art_bitmap)
            if (ArtKind.URI_LOCAL in k) parts += getString(R.string.art_uri_local)
            if (ArtKind.URI_HTTPS in k) parts += getString(R.string.art_uri_https)
            if (parts.isEmpty()) parts += getString(R.string.art_absent)
            tvArt.text = getString(R.string.fmt_art, parts.joinToString(" · "))
            tvArt.setTextColor(
                when {
                    ArtKind.BITMAP in k || ArtKind.URI_LOCAL in k -> Color.WHITE
                    ArtKind.URI_HTTPS in k -> Color.parseColor("#FFD54F")
                    else -> Color.parseColor("#FF8A80")
                }
            )
        }

        val art = s?.bestArt
        if (art != null) ivArt.setImageBitmap(art) else ivArt.setImageResource(R.drawable.bg_art_placeholder)
    }

    // ---------------------------------------------------------------- informe

    private fun setDetails(details: String) {
        tvDetails.text = details
        lastReport = composeReport(details)
    }

    private fun composeReport(details: String): String {
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val head = StringBuilder()
        head.appendLine("CarMusic Diagnostic $version")
        head.appendLine("Fecha: $date")
        head.appendLine(
            "Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        )
        head.appendLine(
            "Acceso a notificaciones: " + if (Diag.isListenerEnabled(this)) "concedido" else "NO concedido"
        )
        listOf(
            tvBluetooth, tvSession, tvPackage, tvTitle, tvArtist,
            tvAlbum, tvDuration, tvPosition, tvState, tvArt
        ).forEach { head.appendLine(it.text) }
        return head.append('\n').append(details).toString()
    }

    private fun copyReport() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CarMusic diagnóstico", lastReport))
            Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(Diag.TAG, "No se pudo copiar el diagnóstico", e)
        }
    }

    private companion object {
        const val REFRESH_DEBOUNCE_MS = 300L
    }
}
